# Blur Icons 7.1 -> ColorOS 16 (icons only), patch edition

Not a Gradle project: the original Blur Icons 7.1 APK is decoded with apktool
in CI, patched by patch/patch.py, rebuilt, aligned and signed.

    input/BlurIcons_7.1.apk   original module (untouched)
    patch/patch.py            retargets Samsung hooks to com.android.launcher

Build: put this folder in a GitHub repo, add the workflow file
(.github/workflows/build.yml, given in chat), run "Build ColorOS Blur Icons"
from the Actions tab, download the artifact BlurIcons-ColorOS.

Install (rooted, LSPosed): uninstall any old Blur Icons first (the signing key
differs), install the APK, LSPosed > Modules > enable it, scope ONLY
"com.android.launcher" (the scope list is patched to that), force-stop the
launcher. Check LSPosed logs for lines starting "icon view hooks",
"icon view fallback hooks", "cell glass".

STATUS: first test build. Not built or run by the author.
Known gaps: folders, app drawer, glass-converted icon artwork (icon factory
hook is a no-op), wallpaper zoom. Other features are disabled by scope, but
their settings pages are still visible in the app.
