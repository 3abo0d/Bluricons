#!/usr/bin/env python3
"""Patch the apktool-decoded Blur Icons 7.1 tree for the ColorOS 16 launcher.

Icons-only edition: SystemUI / lock screen / fingerprint hooks are disabled,
the Samsung launcher targets are retargeted at com.android.launcher.
Every patch is checked: a patch that finds nothing fails the build.
"""
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1])
smali = sorted(root.glob("smali*/dev/flexy/bluricons"))
if not smali:
    sys.exit("no smali/dev/flexy/bluricons in " + str(root))


def files(pattern):
    out = []
    for d in smali:
        out += sorted(d.glob(pattern))
    return out


failed = []


def sub(pattern, old, new, required=True):
    """Replace the exact quoted smali string "old" by "new" in matching files."""
    total = 0
    for f in files(pattern):
        t = f.read_text(encoding="utf-8")
        n = t.count('"%s"' % old)
        if n:
            f.write_text(t.replace('"%s"' % old, '"%s"' % new), encoding="utf-8")
            total += n
    print("%-14s %-62s -> %-42s x%d" % (pattern, old, new, total))
    if required and total == 0:
        failed.append((pattern, old))


L = "com.android.launcher"

# 1. Launcher package everywhere (hook entry, settings provider, settings app)
sub("*.smali", "com.sec.android.app.launcher", L)

# 2. Icon view: BubbleTextView replaces Samsung IconViewImpl. The module's own
#    fallback then hooks TextView.setCompoundDrawables(Relative) for it.
sub("Entry.smali", "com.honeyspace.ui.common.iconview.IconViewImpl",
    "com.android.launcher3.BubbleTextView")

# 3. Icon factory: no ColorOS counterpart wired yet. Point at a class that
#    exists, with a method that does not, so the hook installs as a no-op.
sub("Entry.smali", "com.honeyspace.common.wrapper.LauncherActivityInfoWrapper",
    "com.android.launcher3.icons.BaseIconFactory")
sub("Entry.smali", "semGetBadgedIconForIconTray", "blurIconsNoSuchMethod")

# 4. Cell layouts: match the ColorOS class names
sub("CellGlass.smali", ".WorkspaceCellLayout", ".OplusCellLayout")
sub("CellGlass.smali", ".HotseatCellLayout", ".OplusHotseat")
sub("CellGlass.smali", ".ApplistCellLayout", ".CellLayout")
sub("CellGlass.smali",
    "com.honeyspace.ui.honeypots.workspace.presentation.WorkspaceCellLayout",
    "com.android.launcher3.OplusCellLayout")
sub("CellGlass.smali",
    "com.honeyspace.ui.honeypots.hotseat.presentation.HotseatCellLayout",
    "com.android.launcher3.OplusHotseat")
sub("CellGlass.smali",
    "com.honeyspace.ui.honeypots.applist.presentation.ApplistCellLayout",
    "com.android.launcher3.CellLayout")

# 4b. Icon scope check (IconBlur$Holder.inScope): walks up from each icon and
#     needs a parent class whose name ends with these. ColorOS: OplusCellLayout
#     / CellLayout for home pages and OplusHotseat / Hotseat for the dock.
sub("IconBlur$Holder.smali", ".WorkspaceCellLayout", "CellLayout")
sub("IconBlur$Holder.smali", ".HotseatCellLayout", "Hotseat")
sub("GlassLight.smali", "com.sec.android.app.launcher.Launcher",
    "com.android.launcher.Launcher", required=False)

# 5. Icons only: the SystemUI and biometrics branches can never match
sub("Entry.smali", "com.android.systemui", "disabled.systemui")
sub("Entry.smali", "com.samsung.android.biometrics.app.setting",
    "disabled.biometrics")

# 6. LSPosed scope list (res/values*): launcher only
scope_files = 0
for f in sorted(root.glob("res/values*/*.xml")):
    t = f.read_text(encoding="utf-8")
    if "com.sec.android.app.launcher" in t:
        t = t.replace("com.sec.android.app.launcher", L)
        t = re.sub(r"[ \t]*<item>com\.android\.systemui</item>[ \t]*\r?\n", "", t)
        t = re.sub(
            r"[ \t]*<item>com\.samsung\.android\.biometrics\.app\.setting</item>[ \t]*\r?\n",
            "", t)
        f.write_text(t, encoding="utf-8")
        scope_files += 1
        print("scope list patched:", f)
if scope_files == 0:
    failed.append(("res/values*", "xposedscope"))

if failed:
    sys.exit("PATCH FAILED, nothing matched: %s" % failed)
print("all patches applied")
